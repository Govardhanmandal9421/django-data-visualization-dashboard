from faker import Faker
fake = Faker()
from Data_vi.models import Data , chart
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.image as imgplt
import seaborn as sns
import plotly.graph_objects as go
import os
from django.conf import settings



def generate_data(n):
    for i in range(n) :   
        name = fake.name()  
        email = fake.email()
        city = fake.city()
        state = fake.state()
        country = fake.country()
        age = fake.random_int(min=18, max=65)
        gender = fake.random_element(elements=('Male', 'Female','gay'))
            
    data = Data.objects.create(
        name = name,
        email = email,
        city = city,
        state = state,
        country = country,
        age = age,
        gender = gender,
    )
    data.save()



def generate_charts():
    # Get data from database
    data = Data.objects.all().values()
    df = pd.DataFrame(list(data))
    
    if len(df) == 0:
        return
    
    # Ensure media directories exist
    chart_dirs = [
        os.path.join(settings.MEDIA_ROOT, 'charts', 'bar'),
        os.path.join(settings.MEDIA_ROOT, 'charts', 'scatter'),
        os.path.join(settings.MEDIA_ROOT, 'charts', 'histogram'),
        os.path.join(settings.MEDIA_ROOT, 'charts', 'box'),
        os.path.join(settings.MEDIA_ROOT, 'charts', 'violin'),
        os.path.join(settings.MEDIA_ROOT, 'charts', 'line')
    ]
    
    for directory in chart_dirs:
        os.makedirs(directory, exist_ok=True)
    
    # Sample data for better visualization
    sample_df = df.head(10)
    ages = sample_df['age'].tolist()
    names = [str(name)[:10] for name in sample_df['name'].tolist()]  # Shortened names
    
    # Bar Chart
    plt.figure(figsize=(10, 6))
    bars = plt.bar(range(len(names)), ages)
    plt.xlabel('People')
    plt.ylabel('Age')
    plt.title('Age Distribution - Bar Chart')
    bar_path = os.path.join(settings.MEDIA_ROOT, 'charts', 'bar', 'bar_chart.png')
    plt.savefig(bar_path)
    plt.close()
    
    # Scatter Chart
    plt.figure(figsize=(10, 6))
    plt.scatter(range(len(names)), ages, s=100, alpha=0.7)
    plt.xlabel('Index')
    plt.ylabel('Age')
    plt.title('Age Scatter Plot')
    scatter_path = os.path.join(settings.MEDIA_ROOT, 'charts', 'scatter', 'scatter_chart.png')
    plt.savefig(scatter_path)
    plt.close()
    
    # Histogram
    plt.figure(figsize=(10, 6))
    plt.hist(ages, bins=5, alpha=0.7, color='skyblue', edgecolor='black')
    plt.xlabel('Age')
    plt.ylabel('Frequency')
    plt.title('Age Distribution - Histogram')
    histogram_path = os.path.join(settings.MEDIA_ROOT, 'charts', 'histogram', 'histogram_chart.png')
    plt.savefig(histogram_path)
    plt.close()
    
    # Box Plot
    plt.figure(figsize=(8, 6))
    plt.boxplot(ages)
    plt.ylabel('Age')
    plt.title('Age Distribution - Box Plot')
    box_path = os.path.join(settings.MEDIA_ROOT, 'charts', 'box', 'box_chart.png')
    plt.savefig(box_path)
    plt.close()
    
    # Violin Plot
    plt.figure(figsize=(8, 6))
    parts = plt.violinplot(ages, vert=True, showmeans=False, showmedians=True)
    plt.ylabel('Age')
    plt.title('Age Distribution - Violin Plot')
    violin_path = os.path.join(settings.MEDIA_ROOT, 'charts', 'violin', 'violin_chart.png')
    plt.savefig(violin_path)
    plt.close()
    
    # Line Plot
    plt.figure(figsize=(10, 6))
    plt.plot(range(len(ages)), ages, marker='o', linewidth=2, markersize=8)
    plt.xlabel('Person Index')
    plt.ylabel('Age')
    plt.title('Age Trend - Line Plot')
    line_path = os.path.join(settings.MEDIA_ROOT, 'charts', 'line', 'line_chart.png')
    plt.savefig(line_path)
    plt.close()
    
    # Create or update chart record
    chart_obj, created = chart.objects.get_or_create(id=1)
    chart_obj.Bar_chart = 'charts/bar/bar_chart.png'
    chart_obj.Scatter_chart = 'charts/scatter/scatter_chart.png'
    chart_obj.Histogram_chart = 'charts/histogram/histogram_chart.png'
    chart_obj.Box_chart = 'charts/box/box_chart.png'
    chart_obj.Violin_chart = 'charts/violin/violin_chart.png'
    chart_obj.Line_chart = 'charts/line/line_chart.png'
    chart_obj.save()