from django.shortcuts import render
from Data_vi.demo import generate_data, generate_charts 
from Data_vi.models import Data , chart
from django.core.paginator import Paginator       




# Create your views here.
def dashboard(request):
    generate_data(100)
    generate_charts()

    charts = chart.objects.all()
    all_data = Data.objects.all()

    paginator = Paginator(all_data, 10)  # Show 10 records per page
    page_number = request.GET.get('page')
    data = paginator.get_page(page_number)

    
    context = {
        'data' : data,
        'chart' : charts,
    }
    return render(request,'index.html',context)