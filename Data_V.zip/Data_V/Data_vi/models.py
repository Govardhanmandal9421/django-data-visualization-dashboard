from django.db import models

# Create your models here.
class Data(models.Model):
    name = models.CharField(max_length=100,null=True,blank=True)
    age = models.IntegerField(default=0,null=True,blank=True)
    gender = models.CharField(max_length=10,null=True,blank=True)
    city = models.CharField(max_length=100,null=True,blank=True)
    state = models.CharField(max_length=100,null=True,blank=True)
    country = models.CharField(max_length=100,null=True,blank=True)
    email = models.EmailField(null=True,blank=True)

    def __str__(self):
        return self.name

class chart(models.Model):
    Bar_chart = models.ImageField(upload_to='charts/bar' , default='True')
    Scatter_chart = models.ImageField(upload_to='charts/scatter' , default='True')
    Histogram_chart = models.ImageField(upload_to='charts/histogram' , default='True')
    Box_chart = models.ImageField(upload_to='charts/box' , default='True')
    Violin_chart = models.ImageField(upload_to='charts/violin' , default='True')
    Line_chart = models.ImageField(upload_to='charts/line' , default='True')

    def __str__(self):
        return f"Chart {self.id}"